const btn = document.getElementsByClassName(btn)

btn.addEventListener("click", () =>{
  alert("Información enviada");
  document.getElementById("myForm").reset();
} )
